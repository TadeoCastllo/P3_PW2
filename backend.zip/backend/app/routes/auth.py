from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from passlib.context import CryptContext
from sqlalchemy.orm import Session

# Importaciones de tu proyecto
from app.schemas.schemas import UsuarioOut

router = APIRouter(tags=["Autenticación"])

# Contexto para hashing de contraseñas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Funciones de utilidad
def verify_password(plain_password: str, hashed_password: str):
    """Verifica si la contraseña coincide con el hash almacenado"""
    return pwd_context.verify(plain_password, hashed_password)

def get_user(db: Session, correo: str):
    """Obtiene un usuario de la base de datos por email"""
    return db.query(Usuario).filter(Usuario.correo == correo).first()

def authenticate_user(db: Session, correo: str, password: str):
    """Autentica al usuario verificando credenciales"""
    user = get_user(db, correo)
    if not user:
        return False
    if not verify_password(password, user.contrasena):
        return False
    return user

# Endpoint de login (solo para verificar credenciales)
@router.post("/login", response_model=dict)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """Endpoint para iniciar sesión y obtener token JWT"""
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Correo o contraseña incorrectos",
        )
    # Devuelve un mensaje simple
    return {"mensaje": "Inicio de sesión exitoso"}

# Dependencia para rutas protegidas: pide usuario y contraseña en cada petición
def basic_auth(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """Dependencia para autenticar usuarios en rutas protegidas"""
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales inválidas",
        )
    return user

# Ejemplo de ruta protegida
@router.get("/usuario/me", response_model=UsuarioOut)
async def leer_usuario_actual(current_user: Usuario = Depends(basic_auth)):
    """Obtiene los datos del usuario actual autenticado"""
    return current_user