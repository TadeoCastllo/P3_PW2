from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.question import Examen, Pregunta
from app.models.user import Usuario
from app.schemas.schemas import ExamenCreate, ExamenOut, PreguntaOut

router = APIRouter(prefix="/examenes", tags=["Examenes"])

@router.post("/", response_model=ExamenOut)
def crear_examen(examen: ExamenCreate, db: Session = Depends(get_db)):
    profesor = db.query(Usuario).filter(Usuario.id == examen.profesor_id, Usuario.rol == "profesor").first()
    if not profesor:
        raise HTTPException(status_code=404, detail="Profesor no encontrado")

    nuevo_examen = Examen(**examen.dict())
    db.add(nuevo_examen)
    db.commit()
    db.refresh(nuevo_examen)
    return nuevo_examen

@router.get("/", response_model=list[ExamenOut])
def listar_examenes(db: Session = Depends(get_db)):
    return db.query(Examen).all()

@router.get("/{examen_id}", response_model=ExamenOut)
def obtener_examen(examen_id: int, db: Session = Depends(get_db)):
    examen = db.query(Examen).filter(Examen.id == examen_id).first()
    if not examen:
        raise HTTPException(status_code=404, detail="Examen no encontrado")
    return examen

@router.get("/{examen_id}/preguntas", response_model=list[PreguntaOut])
def obtener_preguntas_examen(examen_id: int, db: Session = Depends(get_db)):
    return db.query(Pregunta).filter(Pregunta.examen_id == examen_id).all()
