from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.answer import RespuestaCreate
from app.schemas.schemas import RespuestaOut
from app.database.db import get_db
from app.services.ia_client import evaluar_respuesta
from app.models import question

router = APIRouter()

@router.post("/responder", response_model=RespuestaOut)
def responder_pregunta(respuesta: RespuestaCreate, db: Session = Depends(get_db)):
    pregunta = db.query(question.Pregunta).filter_by(id=respuesta.pregunta_id).first()
    evaluacion = evaluar_respuesta(pregunta.enunciado, respuesta.respuesta_texto)

    nueva_respuesta = question.Respuesta(
        estudiante_id=respuesta.estudiante_id,
        pregunta_id=respuesta.pregunta_id,
        examen_id=respuesta.examen_id,
        respuesta_texto=respuesta.respuesta_texto,
        calificacion=float(evaluacion.get("calificacion", 0)),
        retroalimentacion_ia=evaluacion.get("retroalimentacion", ""),
        tiempo_respuesta=respuesta.tiempo_respuesta
    )
    db.add(nueva_respuesta)
    db.commit()
    db.refresh(nueva_respuesta)

    return nueva_respuesta
