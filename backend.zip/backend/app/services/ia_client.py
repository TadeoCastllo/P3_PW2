import os
from openai import OpenAI
from dotenv import load_dotenv
import requests
import logging

load_dotenv()

client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    base_url=os.getenv("DEEPSEEK_BASE_URL")
)

def generar_respuesta_con_ia(prompt: str) -> str:
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=[
            {"role": "system", "content": "Eres un asistente experto en programación y evaluación educativa."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        stream=False
    )
    return response.choices[0].message.content

def obtener_respuesta_ia(pregunta: str) -> str:
    try:
        response = requests.post(
            "https://api.ejemplo-ia.com/responder",
            json={"pregunta": pregunta},
            timeout=10
        )
        response.raise_for_status()
        return response.json().get("respuesta", "Sin respuesta de la IA")
    except requests.exceptions.RequestException as e:
        logging.error(f"Error al conectar con la IA: {e}")
        return "No se pudo obtener respuesta de la IA en este momento."
